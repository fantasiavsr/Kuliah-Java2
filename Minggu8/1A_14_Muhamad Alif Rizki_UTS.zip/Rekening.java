package Minggu8;

public class Rekening {
    String noRekening, nama, namaIbu, phone, email;
    int num;

    Rekening(String a, String b, String c, String d, String e, int x){
        noRekening = a;
        nama = b;
        namaIbu = c;
        phone = c;
        email = e;
        num = x;
    }
}

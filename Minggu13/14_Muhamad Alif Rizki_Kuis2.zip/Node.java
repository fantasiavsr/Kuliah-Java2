package Minggu13;

public class Node {
    // Nama: Muhamad Alif Rizki
    // Kelas: TI 1A/14
    // NIM: 2041720196
    
    imigrasi data;
    Node next;

    public Node(imigrasi data, Node next){
        this.data = data;
        this.next = next;
    }
}

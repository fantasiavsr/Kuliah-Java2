package Minggu13;

public class imigrasi {
    // Nama: Muhamad Alif Rizki
    // Kelas: TI 1A/14
    // NIM: 2041720196
    
    String nama;
    int usia;

    public imigrasi(String nama, int usia){
        this.nama = nama;
        this.usia = usia;
    }
}

